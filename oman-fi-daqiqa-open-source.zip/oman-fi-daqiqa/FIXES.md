# Fixes applied to Oman in a Minute

- Account registration and login now use the same request-aware cookie policy as the rest of the authentication flow. Local HTTP development uses `SameSite=Lax` without `Secure`; HTTPS deployments use `SameSite=None; Secure`, so browsers can store the session cookie in both environments.
- Logout clears the account cookie with the same options used to set it.
- Login, registration, and password-reset email addresses are trimmed and normalized to lowercase before database lookups.
- Production startup now refuses to use the known development JWT secret when `JWT_SECRET` is missing.
- Values inserted into the printable assignment HTML are HTML-escaped to prevent user-entered text from being interpreted as markup or script.
- Added a test for local and HTTPS cookie behavior.

## Required configuration

The application still requires its deployment environment to provide a working `DATABASE_URL` for accounts and saved paragraphs. Media uploads also require the configured storage integration credentials. Set a long, random `JWT_SECRET` in production. Do not commit secrets to this source archive.

## Validation status

Automated checks could not be run in this environment because package installation timed out and `pnpm` is not installed. Run `pnpm install --frozen-lockfile`, `pnpm check`, `pnpm test`, and `pnpm build` in the project environment before deployment.
