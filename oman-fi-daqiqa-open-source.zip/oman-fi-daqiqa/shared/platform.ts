export const contentWorkflow = [
  { key: "draft", label: "مسودة" },
  { key: "teacher_review", label: "مراجعة المعلم" },
  { key: "approved", label: "اعتماد" },
  { key: "published", label: "نشر" },
] as const;

export const platformRoles = [
  { key: "supervisor", label: "المعلم المشرف" },
  { key: "teacher", label: "المعلم" },
  { key: "student", label: "الطالب" },
] as const;

export const mediaKinds = ["audio", "video", "pdf", "image"] as const;

export type ContentStatus = (typeof contentWorkflow)[number]["key"];
export type MediaKind = (typeof mediaKinds)[number];

export function canTransition(status: ContentStatus, nextStatus: ContentStatus) {
  const currentIndex = contentWorkflow.findIndex((item) => item.key === status);
  const nextIndex = contentWorkflow.findIndex((item) => item.key === nextStatus);
  return nextIndex >= currentIndex && nextIndex - currentIndex <= 1;
}
