import { and, desc, eq, like, or } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { auditLogs, InsertParagraph, InsertUser, invitations, paragraphs, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId && !user.email) throw new Error("User openId or email is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { ...user };
  const updateSet: Record<string, unknown> = { updatedAt: new Date(), lastSignedIn: new Date() };
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (user.openId === ENV.ownerOpenId || user.email === "salim.alharbi@moe.om") {
    values.role = "admin";
    values.accountRole = "admin";
    values.accountStatus = "active";
    updateSet.role = "admin";
    updateSet.accountRole = "admin";
    updateSet.accountStatus = "active";
  }
  if (user.openId) {
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } else if (user.email) {
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, user.email)).limit(1);
    if (existing.length) await db.update(users).set(updateSet).where(eq(users.id, existing[0].id));
    else await db.insert(users).values(values);
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result[0];
}

export async function listMembers(search?: string, role?: "admin" | "teacher" | "student" | "team") {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (search) conditions.push(or(like(users.name, `%${search}%`), like(users.englishName, `%${search}%`), like(users.email, `%${search}%`)));
  if (role) conditions.push(eq(users.accountRole, role));
  return db.select().from(users).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(users.createdAt));
}

export async function updateMember(id: number, patch: Partial<Pick<InsertUser, "name" | "englishName" | "accountRole" | "accountStatus" | "permissions" | "gender" | "grade" | "className">>) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.update(users).set({ ...patch, updatedAt: new Date() }).where(eq(users.id, id));
  return getUserById(id);
}

export async function createInvitation(input: typeof invitations.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(invitations).values(input);
  return { id: Number(result[0].insertId), email: input.email, expiresAt: input.expiresAt };
}

export async function writeAuditLog(actorUserId: number, action: string, targetUserId?: number, metadata?: Record<string, unknown>) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values({ actorUserId, action, targetUserId, metadata: metadata ? JSON.stringify(metadata) : null });
}

export async function createParagraph(input: InsertParagraph) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.insert(paragraphs).values(input);
  const paragraphId = Number(result[0].insertId);
  const saved = await getParagraphById(paragraphId);
  if (!saved) throw new Error("Paragraph was not confirmed by the database");
  return saved;
}

export async function getParagraphById(paragraphId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  const result = await db.select().from(paragraphs).where(eq(paragraphs.paragraphId, paragraphId)).limit(1);
  return result[0];
}

export async function listParagraphs(createdBy?: number) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  return db.select().from(paragraphs)
    .where(createdBy ? eq(paragraphs.createdBy, createdBy) : undefined)
    .orderBy(desc(paragraphs.updatedAt));
}

export async function updateParagraph(paragraphId: number, patch: Partial<InsertParagraph>) {
  const db = await getDb();
  if (!db) throw new Error("Database unavailable");
  await db.update(paragraphs).set({ ...patch, updatedAt: new Date() }).where(eq(paragraphs.paragraphId, paragraphId));
  const saved = await getParagraphById(paragraphId);
  if (!saved) throw new Error("Paragraph was not found after update");
  return saved;
}
