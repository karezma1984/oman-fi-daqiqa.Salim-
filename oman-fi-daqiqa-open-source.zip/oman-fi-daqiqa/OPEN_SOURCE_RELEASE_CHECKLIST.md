# Open-source release checklist

Before making this repository public:

- [ ] Rotate the database credentials, JWT secret, API keys, and any tokens that were present in the removed `.project-config.json`.
- [ ] Confirm no other real credentials or student/personal data are present in the repository history or files.
- [ ] Run `pnpm install --frozen-lockfile`, `pnpm check`, `pnpm test`, and `pnpm build`.
- [ ] Verify all third-party assets and dependencies may be redistributed under their respective licenses.
- [ ] Create a public GitHub repository and upload the contents of this folder (not the ZIP as a single source file).
- [ ] Add a release note and explain that the original hosting-platform integrations may need replacement for self-hosting.

Security note: `.project-config.json` was removed from this archive because it contained credentials and hosting configuration. Rotate any exposed credentials before publishing. Removing a secret from a new ZIP does not invalidate an already exposed credential or remove it from an older Git history.
