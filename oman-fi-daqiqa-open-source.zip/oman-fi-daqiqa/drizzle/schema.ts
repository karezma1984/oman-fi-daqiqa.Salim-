import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).unique(),
  name: text("name"),
  englishName: text("englishName"),
  email: varchar("email", { length: 320 }).unique(),
  passwordHash: text("passwordHash"),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  accountRole: mysqlEnum("accountRole", ["admin", "teacher", "student", "team"]).default("student").notNull(),
  accountStatus: mysqlEnum("accountStatus", ["pending", "active", "disabled"]).default("pending").notNull(),
  gender: mysqlEnum("gender", ["male", "female"]),
  grade: varchar("grade", { length: 32 }),
  className: varchar("className", { length: 32 }),
  permissions: text("permissions"),
  emailVerifiedAt: timestamp("emailVerifiedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const invitations = mysqlTable("invitations", {
  id: int("id").autoincrement().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  invitedRole: mysqlEnum("invitedRole", ["teacher", "student", "team"]).notNull(),
  permissions: text("permissions"),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  invitedBy: int("invitedBy").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "expired", "revoked"]).default("pending").notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  acceptedAt: timestamp("acceptedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  actorUserId: int("actorUserId").notNull(),
  action: varchar("action", { length: 120 }).notNull(),
  targetUserId: int("targetUserId"),
  metadata: text("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const passwordResetTokens = mysqlTable("passwordResetTokens", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  tokenHash: varchar("tokenHash", { length: 128 }).notNull().unique(),
  expiresAt: timestamp("expiresAt").notNull(),
  usedAt: timestamp("usedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const paragraphs = mysqlTable("paragraphs", {
  paragraphId: int("paragraph_id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  studentName: varchar("student_name", { length: 255 }).notNull(),
  topic: varchar("topic", { length: 120 }).notNull(),
  content: text("content").notNull(),
  audioUrl: text("audio_url"),
  videoUrl: text("video_url"),
  pdfUrl: text("pdf_url"),
  imageUrl: text("image_url"),
  status: mysqlEnum("status", ["draft", "pending_review", "approved", "published", "archived"]).default("draft").notNull(),
  createdBy: int("created_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Invitation = typeof invitations.$inferSelect;
export type AuditLog = typeof auditLogs.$inferSelect;
export type Paragraph = typeof paragraphs.$inferSelect;
export type InsertParagraph = typeof paragraphs.$inferInsert;
