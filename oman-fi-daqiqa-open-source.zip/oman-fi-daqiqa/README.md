# عُمان في دقيقة | Oman in a Minute

A bilingual Arabic/English school radio platform for creating, reviewing, publishing, and printing short Omani heritage assignments.

> دقيقة واحدة… معلومة واحدة… وحكاية عمانية نفتخر بها
>
> One minute… One fact… One Omani story to be proud of.

## Features

- Arabic RTL and English LTR interfaces
- Database-backed assignment/paragraph persistence
- Student and supervisor account workflows
- Audio, image, PDF, and video attachment support
- Governorate, wilayah, and landmark selection with short radio scripts
- Printable assignment pages and share/copy actions

## Technology

- React, Vite, and TypeScript
- Express and tRPC
- Drizzle ORM with MySQL/TiDB
- Tailwind CSS and shadcn/ui

## Requirements

- Node.js version compatible with the dependencies
- pnpm (the package manager specified by `package.json`)
- A MySQL/TiDB database
- A configured object-storage service for media uploads
- Authentication/OAuth and any platform-specific services configured for your deployment

## Local development

1. Clone this repository.
2. Install dependencies: `pnpm install --frozen-lockfile`
3. Create a local environment configuration based on the environment variables required by `server/_core/env.ts`. Do not commit real credentials.
4. Configure a database and media storage service.
5. Run `pnpm check`, `pnpm test`, and `pnpm build`.
6. Start the development server with `pnpm dev`.

The application currently includes integrations designed for its original hosting platform. A public source repository does not automatically make those services available. Before deploying outside that platform, replace or configure OAuth, storage, and platform-specific API integrations for your chosen host.

## Environment and security

- Never commit `.env` files, database URLs, OAuth secrets, API keys, access tokens, or production configuration exports.
- Generate a unique, high-entropy `JWT_SECRET` for each deployment.
- Use a separate database and storage bucket for development and production.
- Restrict administrator access and review file-upload permissions before using the application with students.
- If credentials have ever been committed or shared, rotate them; deleting the file alone does not revoke them.

## Tests and validation

Run:

```sh
pnpm check
pnpm test
pnpm build
```

These commands must pass in your own environment before you treat a deployment as production-ready.

## License

This project is released under the MIT License. See [LICENSE](./LICENSE).
